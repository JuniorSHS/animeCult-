

<?php $__env->startSection('title', "Prochainement"); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row2 justify-content-center align-self-center">
<?php $__currentLoopData = $animes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="blog-card">
    <div class="meta">
      <div class="photo" style="background-image: url(<?php echo e(asset('uploads/anime/'.$anime->image)); ?>)"></div>
    </div>
    <div class="description">
      <h1> <?php echo e($anime->name); ?> </h1>
      <h2> <?php $date = new DateTime($anime->date_release);
        echo $date->format('d/m/Y'); ?> </h2>
      <p> <?php echo $anime->description; ?> </p>
      <p class="read-more">
        <a href="<?php echo e(url('prochainement/'. $anime->name)); ?>">En savoir plus</a>
      </p>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anime-Calendrier\resources\views/frontend/prochainement/index.blade.php ENDPATH**/ ?>