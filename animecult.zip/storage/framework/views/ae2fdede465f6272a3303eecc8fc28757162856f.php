


<?php $__env->startSection('title', 'Catégories'); ?>

<?php $__env->startSection('content'); ?>

<!-- Modal -->
<div class="modal fade" id="deleteModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="<?php echo e(url('admin/delete-category')); ?>" method="POST">
            <?php echo csrf_field(); ?>
                <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Supprimer la catégorie</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="category_delete_id" id="category_id">
                <h6 class="text-center"> Coucou, êtes-vous sûr de vouloir supprimer cette catégorie ? </h6>
                </div>
                <div class="modal-footer">
                <button type="submit" class="btn btn-danger">Oui, je suis sûr.</button>
                </div>
        </form>
      </div>
    </div>
  </div>

<div class="container-fluid px-4 mb-3"><br>
    <h1 class="mt-1">Liste des catégories</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Catégories / Liste des catégories</li>
    </ol>
    <div class="card">
        <div class="card-header">
            <h4>Aperçu des catégories
                <a href="<?php echo e(url('admin/add-category')); ?>"><i class="fa-solid fa-plus-minus float-end"></i></a>
            </h4>
        </div>

        <div class="card-body">

            <div id="bloc-10"><script> setInterval(function(){ var obj = document.getElementById("bloc-10"); obj.innerHTML = "";},3000);</script>
                <?php if(session('message')): ?>
            <div class="alert alert-success">
               <center> <?php echo e(session('message')); ?> </center>
            </div>
            <?php endif; ?>
              </div>

        <table id="myDataTable" class="table table-striped" aria-describedby="myDataTable_info">
                <thead>
                    <tr>
                        <th scope="col"><center>ID</center></th>
                        <th scope="col"><center>Nom</center></th>
                        <th scope="col"><center>Image</center></th>
                        <th scope="col"><center>Status</center></th>
                        <th scope="col"><center>Action</center></th>
                    </tr>
                </thead>
                <tbody>
                    
                    
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="#"><?php echo e($category->id); ?></td>
                        <td data-label="Nom"><?php echo e($category->name); ?></td>
                        <td data-label="Image">
                            <img src="<?php echo e(asset('uploads/category/'.$category->image)); ?>" width="50px" alt="img">
                        </td>
                        <td data-label="État"><?php echo e($category->status == '1' ? 'Masqué':'Public'); ?></td>

                        <td data-label="Action">
                            <a href="<?php echo e(url('admin/edit-category/'.$category->id)); ?>"><i class="fa-solid fa-pen-to-square fa-lg"></i></a>
                            <button type="button" class="deleteCategoryBtn" value="<?php echo e($category->id); ?>"><i class="fa-solid fa-trash-alt fa-lg" color="#ff0000"></i></button>
                            
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function(){
            // $('.deleteCategoryBtn').click(function(e){
                $(document).on('click', '.deleteCategoryBtn', function (e) {
                // });
                e.preventDefault();
                
                var category_id = $(this).val();
                $('#category_id').val(category_id);

                $('#deleteModal').modal('show');
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anime-Calendrier\resources\views/admin/category/index.blade.php ENDPATH**/ ?>