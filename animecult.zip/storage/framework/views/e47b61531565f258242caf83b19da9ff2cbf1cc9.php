

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4 mb-3">
    <h1 class="mt-4">Paramètres du site</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Paramètres du site</li>
    </ol>
    <div class="row">
        <div class="col-md-12">

            <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>


            <div class="card">
                <div class="card-header">
                    <h5>Paramètre</h5>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(url('admin/settings')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label>Nom du site</label>
                        <input type="text" name="nom_site" required <?php if($setting): ?> value="<?php echo e($setting->nom_site); ?>" <?php endif; ?> class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Logo du site</label>
                        <input type="file" name="logo_site" class="form-control"><br>
                        <?php if($setting): ?>
                            <img src="<?php echo e(asset('uploads/settings/'.$setting->logo_site)); ?>" class="img-fluid" alt="Logo" style="max-width: 200px;">
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label>L'entête du site</label>
                        <input type="file" name="favicon_site" class="form-control"><br>
                        <?php if($setting): ?>
                            <img src="<?php echo e(asset('uploads/settings/'.$setting->favicon_site)); ?>" class="img-fluid" alt="Logo" style="max-width: 200px;">
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label>Description</label>
                        <textarea type="text" name="description" class="form-control"><?php if($setting): ?><?php echo e($setting->nom_site); ?> <?php endif; ?></textarea>
                    </div>

                    <h4>SEO - Tags</h4>
                    <div class="mb-3">
                        <label>Meta Titre</label>
                        <input type="text" name="meta_title" <?php if($setting): ?> value="<?php echo e($setting->meta_title); ?>" <?php endif; ?> class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Meta description</label>
                        <textarea type="text" name="meta_description" class="form-control"><?php if($setting): ?> <?php echo e($setting->nom_site); ?> <?php endif; ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label>Meta Mots-clés</label>
                        <input type="text" name="meta_keyword" <?php if($setting): ?> value="<?php echo e($setting->meta_keyword); ?>" <?php endif; ?> class="form-control">
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>

                    </form>
                </div>


            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anime-Calendrier\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>