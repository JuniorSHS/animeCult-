

<?php $__env->startSection('title', 'Nos membres'); ?>

<?php $__env->startSection('content'); ?>



    <div class="container"><br><br>
        <div class="row2">
<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="Body">
        <div class="lksBOX" style="box-shadow:0 0 2px rgba(0,0,0,0.3);">
            <div class="bandBOX" style="background:rgb(166, 57, 57); text-align: center; padding: 12px 7px;"><?php echo e($member->role); ?></div>
            <div class="descBOX">
                <img src="<?php echo e(asset('uploads/membres/'.$member->avatar)); ?>" alt=" ">
                <img src="https://i.pinimg.com/564x/6a/bf/01/6abf0106491a2d0b4a17ec53d438506e.jpg" alt="">
            </div>
            <div class="pseudoBOX" 
            style="background:rgb(166, 57, 57); color:white; text-shadow:-1px 1px 0 rgba(0,0,0,0.1);">
            <a href="<?php echo e(url('membres/'. $member->id)); ?>" class="text-decoration-none"><?php echo e($member->name); ?></a>
            </div> 
        </div>
        <br><br>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <br>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp2\htdocs\Anime-Calendrier\resources\views/frontend/members/view.blade.php ENDPATH**/ ?>