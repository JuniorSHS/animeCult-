

<?php $__env->startSection('title', "$anime->name"); ?>

<?php $__env->startSection('content'); ?>




coucou




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anime-Calendrier\resources\views/frontend/prochainement/viewanime.blade.php ENDPATH**/ ?>