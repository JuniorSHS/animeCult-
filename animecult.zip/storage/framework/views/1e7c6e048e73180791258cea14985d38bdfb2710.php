<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; Anime Calendrier</div>
            <div>
                <a href="#">Vie privée</a>
                &middot;
                <a href="#">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Xampp2\htdocs\Anime-Calendrier\resources\views/layouts/inc/admin-footer.blade.php ENDPATH**/ ?>