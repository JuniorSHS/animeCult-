

<?php $__env->startSection('title', 'Modifier utilisateur'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4 mb-3">
    <div class="card mt-4">
        <div class="card-header">
            <h4>Modifier l'utilisateur <a href="<?php echo e(url('admin/users')); ?>"><i class="fa-solid fa-rotate-left float-end"></i></a></h4>
        </div>
        <div class="card-body">

            <?php if(session('message')): ?>
            <div class="alert alert-success">
                <center> <?php echo e(session('message')); ?> </center>
            </div>
            <?php endif; ?>
            
            <form action="<?php echo e(url('admin/update-user/'.$user->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="name">Identifiant</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
                </div>
                <div class="mb-3">
                    <label>Avatar</label>
                    <input type="file" name="avatar" class="form-control"><br>
                            <img src="<?php echo e(asset('uploads/membres/'.$user->avatar)); ?>" class="img-fluid" alt=" " style="max-width: 150px;">
                </div>
                <div class="form-group">
                    <label for="email">Date de création du compte</label>
                    <input class="form-control" value="<?php echo e($user->created_at->format('d/m/y')); ?>">
                </div>
                <div class="form-group">
                    <label for="role">Rôle</label>
                    <select class="form-control" id="role" name="role">
                        <option value="1" <?php echo e($user->role == '1' ? 'selected':''); ?>>Admin</option>
                        <option value="0" <?php echo e($user->role == '0' ? 'selected':''); ?>>Membre</option>
                    </select>
                </div>
                
                
                <div class="mb-3"><br>
                <center><button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Enregister les modifications</button></center>
                </div>
            </form>

        </div>
    </div>
</div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anime-Calendrier\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>