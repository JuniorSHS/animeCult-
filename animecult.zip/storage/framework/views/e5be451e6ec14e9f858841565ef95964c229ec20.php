

<?php $__env->startSection('title', 'Liste des utilisateurs'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <div class="card mt-4">
        <div class="card-header">
            <h4>Liste des utilisateurs</h4>
        </div>
        <div class="card-body">
            
            <?php if(session('message')): ?>
            <div class="alert alert-success">
               <center> <?php echo e(session('message')); ?> </center>
            </div>
            <?php endif; ?>
            

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th><center>#</center></th>
                        <th><center>Identifiant</center></th>
                        <th><center>Émail</center></th>
                        <th><center>Rôle</center></th>
                        <th><center>Action</center></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><center><?php echo e($item->id); ?></center></td>
                        <td><center><?php echo e($item->name); ?></center></td>
                        <td><center><?php echo e($item->email); ?></center></td>
                        <td><center><?php echo e($item->role == '1' ? 'Admin':'Membre'); ?></center></td>
                        <td>
                            <center><a href="<?php echo e(url('admin/users/'.$item->id)); ?>"><i class="fa-solid fa-user-pen"></i></a></center>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anime-Calendrier\resources\views/admin/users/index.blade.php ENDPATH**/ ?>