<div class="global-navbar" style="background-color: #d1d1d1">
    <div class="container">
        <div class="row justify-content-center align-self-center">
            <div class="col-md-5">
              <?php
                $setting = App\Models\Paremetres::find(1);
              ?>
                <center><a href="<?php echo e(url("/")); ?>"><img src="<?php echo e(asset('uploads/settings/'.$setting->logo_site)); ?>" width="300px" alt="logo"/></a></center>
            </div>
        </div>
    </div>
</div>
<div class="sticky-top">
   <nav class="navbar navbar-expand-lg navbar-dark bg-red">
    <div class="container-fluid">

      <a href="" class="text-menu" class="text-decoration-none" class="navbar-brand d-inline d-sm-inline d-md-none">
        Menu
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(url("/")); ?>">Accueil</a>
          </li>
          <?php
          $categories = App\Models\Category::where('navbar_status','0')->where('status','0')->take(4)->get();
      ?>
        <li class="nav-item"><a class="nav-link" href="#"> Actualités</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Calendrier des sorties</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(url("membres")); ?>">Membres</a></li>
          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Catégories
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cateitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="dropdown-item">
                    <a class="dropdown-item" href="<?php echo e(url('categories/'.$cateitem->slug)); ?>"><center><?php echo e($cateitem->name); ?></center></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </li>
            <li class="nav-item"><a class="nav-link" href="#">Qui sommes-nous ?</a></li>

            <?php if(Auth::check()): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <?php echo e(Auth::user()->name); ?>

                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li class="dropdown-item">
                      <a class="dropdown-item" href="<?php echo e(url('profile')); ?>"><center>Profile</center></a>
                  </li>
                  <li class="dropdown-item">
                    <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><div style="color: #000; !important"><center>Déconnexion</center></div></a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                   <?php echo csrf_field(); ?>
                   </form>
                  </li>
                </ul>
            </li>
            <?php else: ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('login')); ?>">Connexion</a></li>
            <?php endif; ?>

            
          
          


         </ul>
      </div>
    </div>
</nav>
</div>

<?php /**PATH C:\Xampp2\htdocs\Anime-Calendrier\resources\views/layouts/inc/frontend-navbar.blade.php ENDPATH**/ ?>