

<?php $__env->startSection('title', "$category->name"); ?>

<?php $__env->startSection('meta_description', "$category->meta_description"); ?>

<?php $__env->startSection('meta_keyword', "$category->meta_keyword"); ?>

<?php $__env->startSection('content'); ?>

<div class="py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-9">

                <div class="category-heading">
                    <h4 class="mb-0"><?php echo e($category->name); ?></h4>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card card-shadow mt-4">
                    <div class="card-body">
                        <h6 class="float-end" style="font-size: 12px">Publié par <font color="#953b3b"><?php echo e($postitem->user->name); ?></font></h6>
                        <br>
                         <a href="<?php echo e(url('categories/'.$category->slug.'/'.$postitem->slug)); ?>" class="text-decoration-none">
                            <h4 class="post-heading"> <?php echo e($postitem->name); ?> </h4>
                        </a>
                        <br>
                        <h6 style="font-size: 12px">Publié le <font color="#953b3b"><?php echo e($postitem->created_at->format('d-m-y')); ?></font></h6>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="card card-shadow mt-4">
                    <div class="card-body">
                        <h2>Aucune publication trouvé!</h2>
                    </div>
                </div>
                <?php endif; ?>
                <div class="pagination mt-2">
                    <?php echo e($post->links()); ?>

                </div>

            </div>
                        <div class="col-md-3">
                            <div class="border p-2">
                            <h4>Derniers articles</h4>
                            </div>
                        </div>
            </div>
        </div>
    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp2\htdocs\Anime-Calendrier\resources\views/frontend/post/index.blade.php ENDPATH**/ ?>