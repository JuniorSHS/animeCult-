

<?php $__env->startSection('title', 'Liste des utilisateurs'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4 mb-3">
    <h1 class="mt-1">Liste des utilisateurs</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Utilisateurs</li>
    </ol>
    <div class="card mt-4">
        <div class="card-header">
            <h4>Liste des utilisateurs</h4>
        </div>
        <div class="card-body">
            
            <div id="bloc-10"><script> setInterval(function(){ var obj = document.getElementById("bloc-10"); obj.innerHTML = "";},3000);</script>
                <?php if(session('message')): ?>
            <div class="alert alert-success">
               <center> <?php echo e(session('message')); ?> </center>
            </div>
            <?php endif; ?>
              </div>
            
            <table id="myDataTable" class="table table-striped" aria-describedby="myDataTable_info">
                <thead>
                    <tr>
                        
                        <th scope="col"><center>#</center></th>
                        <th scope="col"><center>Identifiant</center></th>
                        <th scope="col"><center>Émail</center></th>
                        <th scope="col"><center>Avatar</center></th>
                        <th scope="col"><center>Rôle</center></th>
                        <th scope="col"><center>Action</center></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="#"><?php echo e($item->id); ?></td>
                        <td data-label="Identifiant"><?php echo e($item->name); ?></td>
                        <td data-label="Émail"><?php echo e($item->email); ?></td>
                        <td data-label="image"><img src="<?php echo e(asset('uploads/membres/'.$item->avatar)); ?>" width="30px" alt="img"></td>
                        <td data-label="Rôle"><?php echo e($item->role == '1' ? 'Admin':'Membre'); ?></td>
                        <td data-label="Action">
                            <a href="<?php echo e(url('admin/edit-user/'.$item->id)); ?>"><i class="fa-solid fa-user-pen fa-lg"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anime-Calendrier\resources\views/admin/user/index.blade.php ENDPATH**/ ?>