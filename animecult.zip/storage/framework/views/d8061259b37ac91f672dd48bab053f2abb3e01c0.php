

<?php $__env->startSection('title', "$setting->nom_site"); ?>

<?php $__env->startSection('meta_description', "$setting->meta_description"); ?>

<?php $__env->startSection('meta_keyword', "$setting->meta_keyword"); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-grey py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="owl-carousel category-carousel owl-theme">
                    <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_cate_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <a href="<?php echo e(url('categories/'.$all_cate_item->slug)); ?>" class="text-decoration-none">
                            <div class="card">
                                <img src="<?php echo e(asset('uploads/category/'.$all_cate_item->image)); ?>" alt="image">
                                <div class="card-body text-center">
                                    <h6 class="text-red"><?php echo e($all_cate_item->name); ?></h6>
                                </div>
                            </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
    </div>
</div>





<div class="py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4>Présentation d'Anime Cult'</h4>
                <div class="underline"></div>
                <p class="text-police">Anime-Cult' c'est un site de communauté pour les fans de l'animation japonaise, des mangas, des webtoons.</p>
                <p class="text-police">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestiae, ea reiciendis. Natus quas animi exercitationem minima, 
                    quaerat cupiditate eveniet cumque non repudiandae est amet rem libero repellendus molestias molestiae quo. Natus quas animi exercitationem minima, 
                    quaerat cupiditate eveniet cumque non repudiandae est amet rem libero repellendus molestias molestiae quo.</p>
                <p class="text-police">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestiae, ea reiciendis. Natus quas animi exercitationem minima, 
                    quaerat cupiditate eveniet cumque non repudiandae est amet rem libero repellendus molestias molestiae quo. Natus quas animi exercitationem minima, 
                    quaerat cupiditate eveniet cumque non repudiandae est amet rem libero repellendus molestias molestiae quo.</p>
            </div>
        </div>
    </div>
</div>

<div class="py-5 bg-grey">
    <div class="container">
        <div class="row2">
            <div class="col-md-12">
                <h4>Publications récentes</h4>
                <div class="underline"></div>
            </div>
                    <div class="owl-carousel category-carousel2 owl-theme">
                        <?php $__currentLoopData = $latest_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest_posts_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div class="flip-card-container" style="--hue: 220">
                                 <div class="flip-card">
                                 <div class="card-front">
                                     <figure>
                                     <div class="img-bg"></div>
                                     <img class="imgCard" src="<?php echo e(asset('uploads/post/'.$latest_posts_item->image)); ?>" alt="">
                                     <figcaption><?php echo e($latest_posts_item->name); ?></figcaption>
                                     </figure>
                             
                                     <ul class="tlb">
                                     <li class="ndt li">Detail 1</li>
                                     <li class="ndt li">Detail 2</li>
                                     <li class="ndt li">Detail 3</li>
                                     </ul>
                                 </div>
                             
                                 <div class="card-back">
                                     <figure>
                                     <div class="img-bg"></div>
                                     <img class="imgCard" src="<?php echo e(asset('uploads/post/'.$latest_posts_item->image)); ?>" alt="">
                                     </figure>
                             
                                     <div class="buttonCard"><i class="fa-solid fa-plus-minus"></i></div>
                             
                                     <div class="design-container">
                                     <span class="design design--1"></span>
                                     <span class="design design--2"></span>
                                     <span class="design design--3"></span>
                                     <span class="design design--4"></span>
                                     <span class="design design--5"></span>
                                     <span class="design design--6"></span>
                                     <span class="design design--7"></span>
                                     <span class="design design--8"></span>
                                     </div>
                                 </div>
                                 </div>
                             </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            
            
    </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp2\htdocs\Anime-Calendrier\resources\views/frontend/index.blade.php ENDPATH**/ ?>