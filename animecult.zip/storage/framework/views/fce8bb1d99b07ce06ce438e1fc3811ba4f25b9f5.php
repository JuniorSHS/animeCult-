

<?php $__env->startSection('content'); ?>

<div class="py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-9">

                <div class="category-heading">
                    <h4 class="mb-0"><?php echo e($post->name); ?></h4>
                </div>

                    <div class="mt-3">
                        <h6><?php echo e($post->category->name .' / ' . $post->name); ?></h6>
                    </div>

                <div class="card card-shadow mt-4">
                    <div class="card-body">
                        <?php echo $post->description; ?>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border p-2 my-2">
                <h4>Derniers articles</h4>
                </div>
                <div class="border p-2 my-2">
                <h4>Derniers articles</h4>
                </div>
                <div class="border p-2 my-2">
                <h4>Derniers articles</h4>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anime-Calendrier\resources\views/frontend/post/apercu.blade.php ENDPATH**/ ?>