<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keyword'); ?>">
    <?php
    $setting = App\Models\Paremetres::find(1);
    ?>
    <link rel="shortcut icon" href="<?php echo e(asset('uploads/settings/'.$setting->favicon_site)); ?>" type="image/x-icon">

    <!-- Scripts -->
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" rel="stylesheet">

</head>
<body>
    <div id="app">

        <?php echo $__env->make('layouts.inc.frontend-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="">
            <?php echo $__env->yieldContent('content'); ?>

        </main>

        <?php echo $__env->make('layouts.inc.frontend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    
    <script>
        $('.category-carousel').owlCarousel({
        loop: true,
        center: true,
        margin: 10,
        responsiveClass: true,
        autoplay:true,
        autoplayTimeout:4000,
        autoplayHoverPause:true,
        dots: false,
        responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:true
        },
        1000:{
            items:5,
            nav:true,
            loop:true
        }
        }
        })
    </script>

<script>
    $('.category-carousel2').owlCarousel({
    loop: true,
    center: true,
    margin: 10,
    responsiveClass: true,
    autoplay:false,
    autoplayTimeout:4000,
    autoplayHoverPause:true,
    dots: false,
    responsive:{
    0:{
        items:1,
        nav:true,
        autoplay:false,
        loop: false

    },
    600:{
        items:3,
        nav:true,
        autoplay:true
    },
    1000:{
        items:5,
        loop: false,
        nav:false,
        loop:true
    }
    }
    })
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Anime-Calendrier\resources\views/layouts/app.blade.php ENDPATH**/ ?>