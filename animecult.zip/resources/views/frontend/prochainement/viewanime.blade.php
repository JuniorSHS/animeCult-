@extends('layouts.app')

@section('title', "$anime->name")

@section('content')




coucou




@endsection